import React from 'react'

const Test = () => {
  return (
    <div>
      
<div class="container text-center">
    <div><h1>Brands List</h1></div>
    <div>
        <table class="table table-bordered">
            <thead class="thead-dark">
            <tr>
               <th>ID</th>
               <th>Name</th>
               <th>Categories</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
              <th>
                <tr>
                    <td>test</td>
                    <td>test</td>
                    <td>test</td>
                    <td>
                        <a >Edit</a>
                        
                        <a>Delete</a>
                    </td>
                </tr>
            </th>
            </tbody>
        </table>
    </div>
</div>

    </div>
  )
}

export default Test
