import React from 'react'
import ExpandMoreIcon from '@mui/icons-material/ExpandMore'
import Breadcrumbs from '@mui/material/Breadcrumbs'
import HomeIcon from '@mui/icons-material/Home'
import { Chip } from '@mui/material'
import { Link } from "react-router-dom"

import { styled } from '@mui/material/styles';
import Button from '@mui/material/Button';


const StyledBreadcrumb = styled(Chip)(({ theme }) => {
  return {
    height: '20px',
    color: 'text-primary'
  }
});



const NewAgency = () => {

  return (
    <>
      <div className='right-content w-100'>
        <div className='card shadow border-0 w-100 d-flex flex-row p-4'>
          <h5 className='mb-0'>Gestion des agences</h5>
          <Breadcrumbs aria-label='breadcrumb' className='breadcrumbs'>
            <StyledBreadcrumb
              className='styledbreadcrumbs'
              component="a"
              href="/"
              label="Dashboard"
              icon={<HomeIcon fontSize="small" />}
            />


            <StyledBreadcrumb
              className='styledbreadcrumbs'
              label="Agences"
              href="#"
              deleteIcon={<ExpandMoreIcon />}
            />
          </Breadcrumbs>
        </div>

        <div className="card shadow border-0 p-3 mt-4">


          <form>

            <div className='row align-items-center justify-content-center'>
              <div className='col-sm-8 '>
                <div className='card p-4 '>
                  <h5 className='align-items-center justify-content-center d-flex'><strong>Créer une nouvelle agence</strong></h5>
                  <div className='form-group mt-3'>
                    <h6>NOM DE L'AGENCE</h6>
                    <input type='text' className='input-50'  />
                  </div>
                  <div className='form-group'>
                    <h6>VILLE DE L'AGENCE</h6>
                    <input type='text' />
                  </div>

                <div  className='align-items-center justify-content-center d-flex '>
                <Link to={''}>
                  <Button className="btn-blue btn-lg btn-round">valider</Button>

                </Link>
              </div>

            </div>
        </div>

        <div className='col-sm-5'>

        </div>
      </div>
    </form >




        </div >



      </div >


    </>
  )
}

export default NewAgency;
